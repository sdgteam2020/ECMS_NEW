﻿$(document).ready(function () {
    $('.Alphanumeric').on('change', function () {
      
        if ($('.Alphanumeric').val().match("^[a-zA-Z0-9 ]*$")) {
            return true
           
        }
        else {
            toastr.warning('Only Alphabets and Numbers allowed');

        }
    });

});